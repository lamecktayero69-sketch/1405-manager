# Build 1405 Manager using only an Android phone

This project now includes a GitHub Actions workflow that builds a debug APK in the cloud.

## Steps
1. Download and extract `1405-manager-android-project.zip` on your phone.
2. Sign in or create an account at https://github.com.
3. Create a new repository named `1405-manager` (Public or Private). Do not add a README/license/gitignore if prompted.
4. Open the repository in your phone browser. Use the `Add file` > `Upload files` option. Upload the contents of the extracted `1405-manager` folder, including the hidden `.github/workflows/android-build.yml` file. If your browser cannot upload a folder or hidden files, switch the browser to Desktop site or use GitHub's mobile app/browser file picker; make sure the workflow file is included at `.github/workflows/android-build.yml`.
5. Commit the uploaded files to the `main` branch.
6. Open the repository's `Actions` tab and select `Build 1405 Manager APK`. If it did not start automatically, press `Run workflow`.
7. Wait for the workflow to finish with a green check. Open that run and scroll to `Artifacts`; download `1405-manager-debug-apk`.
8. Extract the downloaded artifact ZIP. It contains `app-debug.apk`.
9. Tap `app-debug.apk`. If Android blocks it, go to Settings > Apps > Special app access > Install unknown apps, allow your browser or file manager, then try again. Turn that permission off afterward if you prefer.
10. Open 1405 Manager, enter your name, save thresholds, tap `Enable battery reminders`, and grant notifications/overlay permissions as desired.

## Important
- This produces a debug/testing APK, not a Play Store release.
- Do not upload payment account passwords, PINs, API secrets, or private credentials to the repository.
- The first prototype does not collect payments; payment providers need a verified merchant integration.
- Android battery optimisation can delay background behaviour on some phones. Test on your own phone and allow the app to run in the background if Android offers that setting.
