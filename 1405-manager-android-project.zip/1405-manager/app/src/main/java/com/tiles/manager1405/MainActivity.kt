package com.tiles.manager1405

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.ViewGroup
import android.widget.*

class MainActivity : Activity() {
    private val prefs by lazy { getSharedPreferences("manager_settings", Context.MODE_PRIVATE) }
    private lateinit var nameInput: EditText
    private lateinit var chargeSeek: SeekBar
    private lateinit var saverSeek: SeekBar
    private lateinit var chargeValue: TextView
    private lateinit var saverValue: TextView
    private lateinit var status: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.rgb(6, 27, 42)
        window.navigationBarColor = Color.rgb(6, 27, 42)
        buildScreen()
        requestNotificationPermissionIfNeeded()
    }

    private fun buildScreen() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(22), dp(18), dp(22), dp(22))
            setBackgroundColor(Color.rgb(6, 27, 42))
        }
        val scroll = ScrollView(this)
        val content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        scroll.addView(content)

        content.addView(text("⚡ 1405 MANAGER", 27, Color.rgb(255, 204, 0), true))
        content.addView(text("Stay Charged. Stay Connected.", 15, Color.WHITE, false))
        content.addView(gap(20))
        content.addView(text("Your personal reminder settings", 19, Color.WHITE, true))
        content.addView(text("The app works offline. Keep reminders enabled for battery monitoring.", 13, 0xFFB8C8D4.toInt(), false))
        content.addView(gap(14))
        content.addView(text("What should we call you?", 15, Color.WHITE, true))
        nameInput = EditText(this).apply {
            hint = "Enter your name"
            setSingleLine(true)
            setTextColor(Color.WHITE)
            setHintTextColor(0xFF9DB0BE.toInt())
            setPadding(dp(12), dp(10), dp(12), dp(10))
            setText(prefs.getString("user_name", ""))
            setBackgroundColor(0xFF123247.toInt())
        }
        content.addView(nameInput, matchWrap())
        content.addView(gap(18))
        chargeValue = text("Remind me to charge at ${prefs.getInt("charge_level", 20)}%", 16, Color.WHITE, true)
        content.addView(chargeValue)
        chargeSeek = SeekBar(this).apply {
            max = 100
            progress = prefs.getInt("charge_level", 20)
            setOnSeekBarChangeListener(seekListener { chargeValue.text = "Remind me to charge at $it%" })
        }
        content.addView(chargeSeek, matchWrap())
        content.addView(gap(10))
        saverValue = text("Suggest battery saver at ${prefs.getInt("saver_level", 15)}%", 16, Color.WHITE, true)
        content.addView(saverValue)
        saverSeek = SeekBar(this).apply {
            max = 100
            progress = prefs.getInt("saver_level", 15)
            setOnSeekBarChangeListener(seekListener { saverValue.text = "Suggest battery saver at $it%" })
        }
        content.addView(saverSeek, matchWrap())
        content.addView(gap(18))

        val save = button("Save settings", 0xFF00C853.toInt()) {
            val name = nameInput.text.toString().trim()
            if (name.isEmpty()) { nameInput.error = "Please enter your name"; return@button }
            prefs.edit().putString("user_name", name)
                .putInt("charge_level", chargeSeek.progress.coerceAtLeast(1))
                .putInt("saver_level", saverSeek.progress.coerceAtLeast(1)).apply()
            status.text = "Settings saved for $name."
            Toast.makeText(this, "Settings saved", Toast.LENGTH_SHORT).show()
        }
        content.addView(save, matchWrap())
        content.addView(gap(10))
        content.addView(button("Enable battery reminders", 0xFF087FE7.toInt()) {
            val name = nameInput.text.toString().trim()
            if (name.isEmpty()) { nameInput.error = "Enter your name first"; return@button }
            prefs.edit().putString("user_name", name)
                .putInt("charge_level", chargeSeek.progress.coerceAtLeast(1))
                .putInt("saver_level", saverSeek.progress.coerceAtLeast(1)).putBoolean("reminders_enabled", true).apply()
            requestNotificationPermissionIfNeeded()
            startService(Intent(this, ReminderService::class.java))
            status.text = "Battery reminders are running. Keep the app enabled in system settings."
        }, matchWrap())
        content.addView(gap(10))
        content.addView(button("Allow display over other apps", 0xFFFFC107.toInt()) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !Settings.canDrawOverlays(this)) {
                val i = Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
                startActivity(i)
            } else Toast.makeText(this, "Overlay permission is already allowed", Toast.LENGTH_SHORT).show()
        }, matchWrap())
        content.addView(gap(10))
        status = text("Reminders are not enabled yet.", 13, 0xFFB8C8D4.toInt(), false)
        content.addView(status)
        content.addView(gap(22))
        content.addView(text("Payment subscriptions are not active in this first prototype. EcoCash, Omari and InnBucks need a verified merchant/payment integration before real payments can be collected.", 13, 0xFFFFD966.toInt(), false))

        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)
    }

    private fun seekListener(update: (Int) -> Unit) = object : SeekBar.OnSeekBarChangeListener {
        override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) = update(progress)
        override fun onStartTrackingTouch(seekBar: SeekBar?) {}
        override fun onStopTrackingTouch(seekBar: SeekBar?) {}
    }

    private fun text(value: String, size: Int, color: Int, bold: Boolean) = TextView(this).apply {
        text = value; textSize = size.toFloat(); setTextColor(color)
        if (bold) setTypeface(typeface, android.graphics.Typeface.BOLD)
        setPadding(0, dp(5), 0, dp(5))
    }
    private fun gap(h: Int) = android.view.View(this).apply { layoutParams = LinearLayout.LayoutParams(1, dp(h)) }
    private fun matchWrap() = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun button(label: String, color: Int, action: () -> Unit) = Button(this).apply {
        text = label; setTextColor(if (color == 0xFFFFC107.toInt()) Color.BLACK else Color.WHITE)
        setBackgroundColor(color); setOnClickListener { action() }
    }

    private fun requestNotificationPermissionIfNeeded() {
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 100)
        }
    }
}
