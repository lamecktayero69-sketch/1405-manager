package com.tiles.manager1405

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.BatteryManager
import android.os.Build
import android.os.IBinder
import android.speech.tts.TextToSpeech
import android.view.Gravity
import android.view.WindowManager
import android.graphics.PixelFormat
import android.graphics.Color
import android.graphics.Typeface
import android.widget.TextView
import java.util.Locale

class ReminderService : Service(), TextToSpeech.OnInitListener {
    private val prefs by lazy { getSharedPreferences("manager_settings", Context.MODE_PRIVATE) }
    private var tts: TextToSpeech? = null
    private var ttsReady = false
    private var overlay: TextView? = null
    private var lastChargeAlert = false
    private var lastSaverAlert = false
    private var receiverRegistered = false

    private val batteryReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            if (intent?.action != Intent.ACTION_BATTERY_CHANGED) return
            val level = intent.getIntExtra(BatteryManager.EXTRA_LEVEL, -1)
            val scale = intent.getIntExtra(BatteryManager.EXTRA_SCALE, 100).coerceAtLeast(1)
            val pct = (level * 100) / scale
            val status = intent.getIntExtra(BatteryManager.EXTRA_STATUS, -1)
            val charging = status == BatteryManager.BATTERY_STATUS_CHARGING || status == BatteryManager.BATTERY_STATUS_FULL
            val chargeAt = prefs.getInt("charge_level", 20)
            val saverAt = prefs.getInt("saver_level", 15)
            if (charging || pct > chargeAt + 3) lastChargeAlert = false
            if (charging || pct > saverAt + 3) lastSaverAlert = false
            if (!charging && pct <= saverAt && !lastSaverAlert) {
                lastSaverAlert = true
                remind("${greetingName()}, your battery is at $pct percent. Please turn on battery saver.", "Battery saver reminder", true)
            } else if (!charging && pct <= chargeAt && !lastChargeAlert) {
                lastChargeAlert = true
                remind("${greetingName()}, your battery is at $pct percent. Please charge your phone.", "Time to charge", false)
            }
        }
    }

    override fun onCreate() {
        super.onCreate()
        createChannel()
        startForeground(1405, ongoingNotification())
        tts = TextToSpeech(this, this)
        registerReceiver(batteryReceiver, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        receiverRegistered = true
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int = START_STICKY

    override fun onInit(status: Int) {
        ttsReady = status == TextToSpeech.SUCCESS
        if (ttsReady) tts?.language = Locale.getDefault()
    }

    private fun greetingName(): String = prefs.getString("user_name", "there")?.takeIf { it.isNotBlank() } ?: "there"

    private fun remind(message: String, title: String, saver: Boolean) {
        val manager = getSystemService(NotificationManager::class.java)
        val open = PendingIntent.getActivity(this, 1405, Intent(this, MainActivity::class.java), PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val notification = if (Build.VERSION.SDK_INT >= 26) Notification.Builder(this, "battery_reminders") else Notification.Builder(this)
        notification.setSmallIcon(android.R.drawable.ic_lock_idle_charging)
            .setContentTitle(title).setContentText(message).setContentIntent(open).setAutoCancel(true)
        manager.notify(if (saver) 1407 else 1406, notification.build())
        if (ttsReady) tts?.speak(message, TextToSpeech.QUEUE_FLUSH, null, "1405-${if (saver) "saver" else "charge"}")
        showOverlay(message)
    }

    private fun showOverlay(message: String) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.M || !android.provider.Settings.canDrawOverlays(this)) return
        try {
            val wm = getSystemService(WINDOW_SERVICE) as WindowManager
            overlay?.let { try { wm.removeView(it) } catch (_: Exception) {} }
            val view = TextView(this).apply {
                text = "⚡ 1405 Manager\n$message\nTap to dismiss"
                textSize = 17f; setTextColor(Color.WHITE); setTypeface(typeface, Typeface.BOLD)
                setPadding(28, 24, 28, 24); setBackgroundColor(0xFF08283A.toInt())
                setOnClickListener { try { wm.removeView(this) } catch (_: Exception) {}; overlay = null }
            }
            val type = if (Build.VERSION.SDK_INT >= 26) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY else WindowManager.LayoutParams.TYPE_PHONE
            val params = WindowManager.LayoutParams(WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.WRAP_CONTENT, type,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN, PixelFormat.TRANSLUCENT)
            params.gravity = Gravity.TOP
            wm.addView(view, params)
            overlay = view
            view.postDelayed({ try { wm.removeView(view) } catch (_: Exception) {}; if (overlay === view) overlay = null }, 12000)
        } catch (_: Exception) { }
    }

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            val channel = NotificationChannel("battery_reminders", "Battery reminders", NotificationManager.IMPORTANCE_HIGH)
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }

    private fun ongoingNotification(): Notification {
        val open = PendingIntent.getActivity(this, 1404, Intent(this, MainActivity::class.java), PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val b = if (Build.VERSION.SDK_INT >= 26) Notification.Builder(this, "battery_reminders") else Notification.Builder(this)
        return b.setSmallIcon(android.R.drawable.ic_lock_idle_charging).setContentTitle("1405 Manager is active")
            .setContentText("Watching your battery level offline").setContentIntent(open).setOngoing(true).build()
    }

    override fun onDestroy() {
        if (receiverRegistered) try { unregisterReceiver(batteryReceiver) } catch (_: Exception) {}
        tts?.stop(); tts?.shutdown()
        overlay?.let { try { (getSystemService(WINDOW_SERVICE) as WindowManager).removeView(it) } catch (_: Exception) {} }
        super.onDestroy()
    }
    override fun onBind(intent: Intent?): IBinder? = null
}
