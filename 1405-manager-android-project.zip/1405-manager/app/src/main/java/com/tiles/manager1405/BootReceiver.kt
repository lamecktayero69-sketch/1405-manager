package com.tiles.manager1405

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        if (intent?.action == Intent.ACTION_BOOT_COMPLETED) {
            val prefs = context.getSharedPreferences("manager_settings", Context.MODE_PRIVATE)
            if (prefs.getBoolean("reminders_enabled", false)) context.startService(Intent(context, ReminderService::class.java))
        }
    }
}
