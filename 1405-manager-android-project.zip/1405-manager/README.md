# 1405 Manager — Android starter project

This is the first working-code prototype for the 1405 Manager app. It is a native Kotlin Android project, not yet a compiled APK.

## Included in this prototype
- User name field, saved locally on the phone.
- Configurable charge and battery-saver percentage thresholds.
- Offline battery-level monitoring while the foreground reminder service is running.
- Spoken reminders using Android Text-to-Speech, including the user's saved name.
- Android notifications and optional “display over other apps” overlay.
- Local settings storage; no account or internet connection is required for reminders.

## Not included yet
- EcoCash, Omari, or InnBucks payment processing. These require approved merchant credentials and a supported provider/API integration; do not put payment secrets in the app itself.
- A polished production icon, full history screen, and final QA across different phone models.
- A signed APK. This environment does not have the Android SDK/Gradle installed, so the project has not been compiled here.

## Build it on a computer
1. Install Android Studio from the official Android developer website.
2. Extract this ZIP and open the `1405-manager` folder in Android Studio.
3. Allow Gradle sync and install the Android SDK requested by Android Studio.
4. Connect an Android phone with Developer options and USB debugging enabled, or create an emulator.
5. Press **Run** to install the app.
6. Enter your name, set thresholds, save, then tap **Enable battery reminders**.
7. Allow notifications. If you want the pop-up overlay, tap **Allow display over other apps** and enable it in Android settings.
8. Test safely by setting a high charge threshold temporarily; then restore your preferred percentages. The reminder service needs to be started by the user and some Android manufacturers may restrict background services; exempt the app from battery optimisation if needed.

## Notes
- Android can limit background activity, and text-to-speech depends on the phone's installed speech engine and language packs.
- The overlay permission is optional; standard notifications are the fallback.
- The prototype uses a foreground service so Android shows an ongoing notification while it monitors battery level.
- Before public release, update the app's target SDK and foreground-service declaration to current Play requirements, test on real devices, and review privacy disclosures.
